# LinkChat — Firebase group chat + multiplayer mini-game

A starter web app built with HTML/CSS/JavaScript and Firebase Realtime Database, Anonymous Authentication, and Cloud Storage.

## Setup

1. Open Firebase Console for project `mini-instagram-95485`.
2. **Authentication → Sign-in method**: enable **Anonymous**.
3. **Realtime Database → Rules**: publish the rules in `database.rules.json`.
4. **Storage → Get started** (if not enabled), then publish `storage.rules`.
5. Host `index.html` on HTTPS, e.g. GitHub Pages. You can also test with a local development server.
6. Share the same URL with friends. The room is selected by the `?room=...` query parameter. The app's Copy link button copies the room URL.

## Important notes

- The provided Firebase web config is included in `index.html`. Firebase web API keys are identifiers, not server secrets; database and storage security rules are essential.
- Anonymous sign-in must be enabled before the app can connect.
- Storage uploads are limited in this starter to 100 MB per file in the UI. Actual Firebase plan quotas and upload limits apply.
- Online presence is best-effort and depends on connectivity/browser lifecycle.
- Tic-Tac-Toe currently assigns X and O to the first two online users when a round starts. Additional room members can watch.
- This is a prototype, not a complete WhatsApp replacement. It does not yet include end-to-end encryption, private DMs, push notifications, moderation, message deletion, or reliable file-size/type policies enforced server-side.
- Do not store sensitive/private files in a public room. Tighten rules and add App Check/rate limits before public launch.
